Admin = {
    web3Provider: null,
    contracts: {},
    account: '0x0',
    hasVoted: false,
  
    
    init: function() {
      console.log("called init");
      return Admin.initWeb3();
    },
  
    initWeb3: function() {
      // TODO: refactor conditional
      console.log("called initWeb3");
      if (typeof web3 !== 'undefined') {
        // If a web3 instance is already provided by Meta Mask.
        Admin.web3Provider = web3.currentProvider;
        web3 = new Web3(web3.currentProvider);
      } else {
        // Specify default instance if no web3 instance provided
        Admin.web3Provider = new Web3.providers.HttpProvider('http://localhost:8545');
        web3 = new Web3(Admin.web3Provider);
      }
      return Admin.initContract();
    },
  
    initContract: function() {
      console.log("Called initContract");
      $.getJSON("Election.json", function(election) {
        // Instantiate a new truffle contract from the artifact
        Admin.contracts.Election = TruffleContract(election);
        // Connect provider to interact with contract
        Admin.contracts.Election.setProvider(Admin.web3Provider);
  
        return Admin.listenForEvents();
        
        console.log("called initContractfdsdhere");
        //Admin.render();
      });
    },
  
    // Listen for events emitted from the contract
    listenForEvents: function() {
      console.log("called listenForEvents");
      Admin.contracts.Election.deployed().then(function(instance) {
        console.log("Elections has been deployed");
        // Restart Chrome if you are unable to receive this event
        // This is a known issue with Metamask
        // https://github.com/MetaMask/metamask-extension/issues/2393
        instance.votedEvent({}, {
          fromBlock: 0,
          toBlock: 'latest'
        }).watch(function(error, event) {
          console.log("event triggered", error, event)
          // Reload when a new vote is recorded
          Admin.render();
          console.log("called render here");
        });
      });
    },
  
    render: function() {
      console.log("here 22323423");
      var electionInstance;
      var newUserList = $("#newUserList");
  
  
      //input = prompt("Waiting"); 
      // Load account data
      // web3.eth.getCoinbase(function(err, account) {
  
      //   if (err === null) {
      //     Admin.account = account;
      //     console.log(account);
      //     $("#accountAddress").html("Your Account: " + account);
      //   }
      // });
  
      if(web3.currentProvider.enable){
        //For metamask
        web3.currentProvider.enable().then(function(acc){
            Admin.account = acc[0];
            $("#accountAddress").html("Your Account: " + Admin.account);
        });
      } else{
        Admin.account = web3.eth.accounts[0];
        $("#accountAddress").html("Your Account: " + Admin.account);
      }
  
      console.log("Your acc" + Admin.account)
      //input = prompt("Waiting"); 
      // Load contract data
      Admin.contracts.Election.deployed().then(function(instance) {
  
        Admin.checkUser(instance).then(function(validUser) {
            console.log(validUser);
          if (validUser) {
            return instance.candidatesCount().then(function(candidateCount) {
              Admin.contracts.Election.deployed().then(function(instance) {
                electionInstance = instance;
                candidatesCount = electionInstance.candidatesCount();
                return candidatesCount;
              }).then(function(candidatesCount) {
                var candidatesResults = $("#candidatesResults");
                candidatesResults.empty();
            
                var candidatesSelect = $('#candidatesSelect');
                candidatesSelect.empty();
                console.log("Number of candidates: " + candidatesCount);
                for (var i = 1; i <= candidatesCount.toNumber(); i++) {
                  electionInstance.candidates(i).then(function(candidate) {
                    var id = candidate[0];
                    var name = candidate[1];
                    var voteCount = candidate[2];
            
                    // Render candidate Result
                    var candidateTemplate = "<tr><th>" + id + "</th><td>" + name + "</td><td>" + voteCount + "</td></tr>"
                    candidatesResults.Adminend(candidateTemplate);
            
                    // Render candidate ballot option
                    var candidateOption = "<option value='" + id + "' >" + name + "</ option>"
                    candidatesSelect.Adminend(candidateOption);
                  });
                }
                return electionInstance.voters(Admin.account);
              }).then(function(hasVoted) {
                if(hasVoted) {
                  $('form').hide();
                }
                loader.hide();
                content.show();
              }).catch(function(error) {
                  console.warn(error);
              });
            });}
            else {
              console.log("Not added")
              newUserList.hide();
              
            }
            
        });
        })
      console.log("All Done");
    },
  
    checkUser : function(instance) {
      console.log("checkUser");
      return instance.admin().then(function(adminId) {
          if (Admin.account == adminId) return true;

          return false;
      })
    },
  
    castVote: function() {
      var candidateId = $('#candidatesSelect').val();
      Admin.contracts.Election.deployed().then(function(instance) {
        return instance.vote(candidateId, { from: Admin.account });
      }).then(function(result) {
        // Wait for votes to update
        $("#content").hide();
        $("#loader").show();
      }).catch(function(err) {
        console.error(err);
      });
    },
  
    createUser: function() {
      console.log("Creating user");
      var name = $('#name').val();
      Admin.contracts.Election.deployed().then(function(instance) {
        return instance.addUsers(name, Admin.account);
      })
    }
  };
  
  
  
  $(function() {
    $(window).load(function() {
        console.log("hello there")
      Admin.init();
    });
  });
  